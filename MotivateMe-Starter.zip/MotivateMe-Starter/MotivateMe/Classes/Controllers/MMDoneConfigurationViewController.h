//
//  MMDoneConfigurationViewController.h
//  MotivateMe
//
//  Created by Dani Arnaout on 8/17/13.
//  Copyright (c) 2013 Dani Arnaout. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MMDoneConfigurationViewController : UIViewController

@end
