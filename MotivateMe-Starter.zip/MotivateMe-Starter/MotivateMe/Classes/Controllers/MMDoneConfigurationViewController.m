//
//  MMDoneConfigurationViewController.m
//  MotivateMe
//
//  Created by Dani Arnaout on 8/17/13.
//  Copyright (c) 2013 Dani Arnaout. All rights reserved.
//

#import "MMDoneConfigurationViewController.h"

@interface MMDoneConfigurationViewController ()

@end

@implementation MMDoneConfigurationViewController

//------------------------------------------
// IBAction Methods
//------------------------------------------
#pragma mark - IBAction Methods

- (IBAction)motivateMeButtonEvenTouchUpInside
{
    // Proceed to main screen
    [self dismissViewControllerAnimated:YES completion:NULL];
}

@end
